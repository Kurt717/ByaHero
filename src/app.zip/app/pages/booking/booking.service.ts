import { Injectable } from '@angular/core';

export interface TripSummary {
  operator: string;
  from: string;
  to: string;
  eta: string;
  fare: string;       // base one-way fare per seat, e.g. '₱ 620'
  seatsLeft: string;  // e.g. '18 seats left'
  status: string;     // 'on-time' | 'delayed'
}

export type FareClass = 'saver' | 'plus' | 'premium';
export type PaymentMethod = 'gcash' | 'card' | 'cash';

export interface FareClassOption {
  id: FareClass;
  label: string;
  tagline: string;
  icon: string;
  multiplier: number;
}

@Injectable({ providedIn: 'root' })
export class BookingService {

  trip: TripSummary | null = null;
  travelDate = '';
  passengerCount = 1;
  fareClass: FareClass = 'saver';
  selectedSeats: string[] = [];
  paymentMethod: PaymentMethod = 'gcash';
  bookingRef = '';

  readonly fareClasses: FareClassOption[] = [
    { id: 'saver',   label: 'Saver',   tagline: 'Standard reclining seat',        icon: 'bus-outline',      multiplier: 1 },
    { id: 'plus',    label: 'Plus',    tagline: 'Extra legroom, window priority', icon: 'flash-outline',    multiplier: 1.35 },
    { id: 'premium', label: 'Premium', tagline: 'Wide seat + onboard snack',      icon: 'sparkles-outline', multiplier: 1.75 },
  ];

  get selectedFareClass(): FareClassOption {
    return this.fareClasses.find(f => f.id === this.fareClass) ?? this.fareClasses[0];
  }

  get baseFare(): number {
    if (!this.trip) return 0;
    const n = Number(this.trip.fare.replace(/[^0-9.]/g, ''));
    return isNaN(n) ? 0 : n;
  }

  get seatFare(): number {
    return Math.round(this.baseFare * this.selectedFareClass.multiplier);
  }

  get subtotal(): number {
    const seats = this.selectedSeats.length || this.passengerCount;
    return this.seatFare * seats;
  }

  get serviceFee(): number {
    return this.subtotal ? 15 : 0;
  }

  get total(): number {
    return this.subtotal + this.serviceFee;
  }

  formatCurrency(n: number): string {
    return '₱ ' + n.toLocaleString('en-PH');
  }

  startBooking(trip: TripSummary) {
    this.trip = trip;
    this.passengerCount = 1;
    this.fareClass = 'saver';
    this.selectedSeats = [];
    this.paymentMethod = 'gcash';
    this.bookingRef = '';
    const d = new Date();
    d.setDate(d.getDate() + 1);
    this.travelDate = d.toDateString();
  }

  generateBookingRef(): string {
    this.bookingRef = 'BYH-' + Math.floor(10000 + Math.random() * 89999);
    return this.bookingRef;
  }

  reset() {
    this.trip = null;
    this.selectedSeats = [];
    this.bookingRef = '';
  }
}