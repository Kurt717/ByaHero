import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonContent, IonIcon } from '@ionic/angular';
import { Router } from '@angular/router';
import { addIcons } from 'ionicons';
import {
  arrowBackOutline, calendarOutline, removeOutline, addOutline,
  busOutline, flashOutline, sparklesOutline, checkmarkCircle,
  timeOutline, chevronForwardOutline, radioButtonOn
} from 'ionicons/icons';
import { BookingService } from '../booking.service';

addIcons({
  'arrow-back-outline': arrowBackOutline, 'calendar-outline': calendarOutline,
  'remove-outline': removeOutline, 'add-outline': addOutline,
  'bus-outline': busOutline, 'flash-outline': flashOutline,
  'sparkles-outline': sparklesOutline, 'checkmark-circle': checkmarkCircle,
  'time-outline': timeOutline, 'chevron-forward-outline': chevronForwardOutline,
  'radio-button-on': radioButtonOn
});

interface DayOption { iso: string; dow: string; day: string; }

@Component({
  selector: 'app-trip-details',
  standalone: true,
  imports: [CommonModule, IonContent, IonIcon],
  templateUrl: './trip-details.page.html',
  styleUrls: ['./trip-details.page.scss']
})
export class TripDetailsPage implements OnInit {

  days: DayOption[] = [];

  constructor(public booking: BookingService, private router: Router) {
      addIcons({arrowBackOutline,busOutline,removeOutline,addOutline,checkmarkCircle,chevronForwardOutline});}

  ngOnInit() {
    if (!this.booking.trip) {
      this.router.navigateByUrl('/home');
      return;
    }
    this.buildDays();
    if (!this.booking.travelDate) {
      this.booking.travelDate = this.days[0].iso;
    }
  }

    formatFcPrice(multiplier: number): string {
    return this.booking.formatCurrency(Math.round(this.booking.baseFare * multiplier));
  }

  buildDays() {
    const names = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const out: DayOption[] = [];
    for (let i = 1; i <= 6; i++) {
      const d = new Date();
      d.setDate(d.getDate() + i);
      out.push({ iso: d.toDateString(), dow: names[d.getDay()], day: String(d.getDate()) });
    }
    this.days = out;
  }

  get maxPassengers(): number {
    const n = Number((this.booking.trip?.seatsLeft || '').replace(/[^0-9]/g, ''));
    return Math.max(1, Math.min(isNaN(n) ? 6 : n, 6));
  }

  decreasePassengers() {
    if (this.booking.passengerCount > 1) this.booking.passengerCount--;
  }

  increasePassengers() {
    if (this.booking.passengerCount < this.maxPassengers) this.booking.passengerCount++;
  }

  selectFareClass(id: 'saver' | 'plus' | 'premium') {
    this.booking.fareClass = id;
  }

  goBack() { this.router.navigateByUrl('/home'); }

  continue() { this.router.navigateByUrl('/booking/seats'); }
}